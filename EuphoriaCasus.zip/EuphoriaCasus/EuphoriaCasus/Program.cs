﻿using EuphoriaCasus.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml;
using System.Xml.Serialization;

namespace EuphoriaCasus
{
    class Program
    {
        static void Main(string[] args)
        {
            var resourceDir = Path.Combine(Directory.GetCurrentDirectory(), "Resources");
            var locationPaths = Directory.GetFiles(resourceDir);
            var locations = new List<Location>();
            
            foreach(var locationString in locationPaths)
            {
                var serializer = new XmlSerializer(typeof(Location));
                Location location;
                using (XmlReader reader = XmlReader.Create(locationString))
                {
                    location = (Location)serializer.Deserialize(reader);
                }

                locations.Add(location);
            }

            var start = locations.Single(l => l.Id == 1);
            locations.Remove(start);

            var lastLocation = CalculateRoute(start, locations);

            // Calculate the distance of the last location to the base location 'Wilhelminaplein'
        }

        private static Location CalculateRoute(Location startFrom, List<Location> toDo)
        {
            var distances = startFrom.Distances.Where(d => d.Km != 0);
            if (!distances.Any())
            {
                return startFrom;
            }

            var lowestKilometerValue = distances.Min(d => d.Km);
            var distance = startFrom.Distances.Single(d => d.Km == lowestKilometerValue);

            var next = toDo.Single(l => l.Id == distance.Id);
            Console.WriteLine($"Start from {startFrom.Name} and drive {distance.Km} KM to {next.Name}.");

            foreach (var location in toDo)
            {
                var previousLocation = location.Distances.Single(x => x.Id == startFrom.Id);
                location.Distances.Remove(previousLocation);
            }

            toDo.Remove(startFrom);

            if (toDo.Any())
            {
                return CalculateRoute(next, toDo);
            }

            return startFrom;
        }
    }
}
